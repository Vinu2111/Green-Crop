package lk.ijse.green_shadow_backend.entity;

import java.io.Serializable;

public interface SuperEntity extends Serializable {
}
