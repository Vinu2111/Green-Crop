package lk.ijse.green_shadow_backend.entity;

public enum EquipmentType {
    ELECTRICAL,
    MECHANICAL
}
