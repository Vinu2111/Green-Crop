package lk.ijse.green_shadow_backend.entity;

public enum Gender {
    MALE,
    FEMALE
}
