package lk.ijse.green_shadow_backend.entity;

public enum Role {
    MANAGER,
    ADMINISTRATIVE,
    SCIENTIST,
    OTHER
}
