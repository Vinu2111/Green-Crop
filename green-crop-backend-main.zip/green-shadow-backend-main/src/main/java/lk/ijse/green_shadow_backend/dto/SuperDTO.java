package lk.ijse.green_shadow_backend.dto;

import java.io.Serializable;

public interface SuperDTO extends Serializable {
}
