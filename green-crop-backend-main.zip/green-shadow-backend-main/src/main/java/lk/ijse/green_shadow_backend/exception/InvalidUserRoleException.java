package lk.ijse.green_shadow_backend.exception;

public class InvalidUserRoleException extends RuntimeException{
    public InvalidUserRoleException(String message) {
        super(message);
    }
}
